<!-- Scripts -->
<script src="{{ asset('website/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('website/js/purecounter.min.js') }}"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  -->
@if('http://127.0.0.1:8000' ==  url()->current() ||  url()->current() == 'https://demo.bestessaywritingservices.com.au' || url()->current() ==  'https://bestessaywritingservices.com.au')
    <script src="{{ asset('website/js/swiper.min.js') }}"></script>
@endif
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="{{ asset('website/js/script.js?v=1.2') }}"></script>


