 <!-- Styles -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
<link href="{{ asset('website/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('website/css/fontawesome-all.min.css') }}" rel="stylesheet">
<link href="{{ asset('website/css/style.css?v=1.4') }}" rel="stylesheet">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<style>
    .table-bordered>:not(caption)>*>* {
    border-width: 2px 2px !important;
    }
</style>