<?php

return [
    'site_title' => 'Admin',
];