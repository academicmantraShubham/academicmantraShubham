<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?>  Sub<?php echo e(trans('cruds.menu.title_singular')); ?> of <?php echo e($menu->title); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.menu.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="last_url" value="<?php echo e(URL::previous()); ?>">
            <input type="hidden" name="parent_id" value="<?php echo e($menu->id); ?>">
            <div class="row">
                <div class="col-md-5">
                    <div class="form-group">
                        <label class="required" for="title"><?php echo e(trans('cruds.menu.fields.title')); ?></label>
                        <input class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" type="text" name="title" id="title" value="<?php echo e(old('title', '')); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('title')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.menu.fields.title_helper')); ?></span>
                    </div>
                </div>

                <div class="col-md-5">
                    <div class="form-group">
                        <label class="required" for="title"><?php echo e(trans('cruds.menu.fields.slug')); ?></label>
                        <input class="form-control <?php echo e($errors->has('slug') ? 'is-invalid' : ''); ?>" type="text" name="slug" id="slug" value="<?php echo e(old('slug', '')); ?>" required>
                        <?php if($errors->has('slug')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('slug')); ?>

                            </div>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.menu.fields.slug_helper')); ?></span>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="form-group">
                        <label class="required" for="content"><?php echo e(trans('Has Content')); ?> ?</label>
                        <select class="form-control select2 <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" name="content" id="content" required>
                            <option hidden="" disabled="disabled" selected="selected" value="">Has Content</option>
                            <option value="1" <?php echo e(old('content', '') == 1 ? 'selected' : ''); ?>>Yes</option>
                            <option value="0"  <?php echo e(old('content', '') == 0 ? 'selected' : ''); ?>>No</option>
                        </select>
                        <?php if($errors->has('content')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('content')); ?>

                            </div>
                         <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div id="content_data" style="display: none">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="required" for="ctitle">Content <?php echo e(trans('cruds.contentPage.fields.title')); ?></label>
                            <input class="form-control <?php echo e($errors->has('ctitle') ? 'is-invalid' : ''); ?>" type="text" name="ctitle" id="title" value="<?php echo e(old('ctitle', '')); ?>" >
                            <?php if($errors->has('ctitle')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('ctitle')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.title_helper')); ?></span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="" for="meta_title"><?php echo e(trans('Meta Title')); ?></label>
                            <input class="form-control <?php echo e($errors->has('meta_title') ? 'is-invalid' : ''); ?>" type="text" name="meta_title" id="meta_title" value="<?php echo e(old('meta_title', '')); ?>" >
                            <?php if($errors->has('meta_title')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('meta_title')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.title_helper')); ?></span>
                        </div>
                    </div>
    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="" for="meta_keyword"><?php echo e(trans('Meta Keywords')); ?></label>
                            <input class="form-control <?php echo e($errors->has('meta_keyword') ? 'is-invalid' : ''); ?>" type="text" name="meta_keyword" id="meta_keyword" value="<?php echo e(old('meta_keyword', '')); ?>" >
                            <?php if($errors->has('meta_keyword')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('meta_keyword')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.title_helper')); ?></span>
                        </div>
                    </div>
    
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="meta_description"><?php echo e(trans('Meta Description')); ?></label>
                            <textarea class="form-control <?php echo e($errors->has('meta_description') ? 'is-invalid' : ''); ?>" name="meta_description" id="meta_description"><?php echo e(old('meta_description')); ?></textarea>
                            <?php if($errors->has('meta_description')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('meta_description')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.excerpt_helper')); ?></span>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="page_text"><?php echo e(trans('cruds.contentPage.fields.page_text')); ?></label>
                    <textarea class="form-control ckeditor <?php echo e($errors->has('page_text') ? 'is-invalid' : ''); ?>" name="page_text" id="page_text"><?php echo old('page_text'); ?></textarea>
                    <?php if($errors->has('page_text')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('page_text')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.page_text_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="excerpt"><?php echo e(trans('cruds.contentPage.fields.excerpt')); ?></label>
                    <textarea class="form-control ckeditor<?php echo e($errors->has('excerpt') ? 'is-invalid' : ''); ?>" name="excerpt" id="excerpt"><?php echo e(old('excerpt')); ?></textarea>
                    <?php if($errors->has('excerpt')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('excerpt')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.excerpt_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="featured_image"><?php echo e(trans('cruds.contentPage.fields.featured_image')); ?></label>
                    <div class="needsclick dropzone <?php echo e($errors->has('featured_image') ? 'is-invalid' : ''); ?>" id="featured_image-dropzone">
                    </div>
                    <?php if($errors->has('featured_image')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('featured_image')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.contentPage.fields.featured_image_helper')); ?></span>
                </div>
            </div>

            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('#slug').keyup(function() {
        var Text = $(this).val();
        Text = Text.toLowerCase();
        Text = Text.replace(/[^a-zA-Z0-9]+/g,'-');
        $("#slug").val(Text);     
    });

    $('input#title').keyup(function () {
         $(this).val(
            $(this).val().toLowerCase().replace(/\b[a-z]/g, function(letter) {
                    return letter.toUpperCase();
            })
        );
    });

    $('#content').change(function() {
        var Text = $(this).val();
        if (Text == 1) {
            $('#content_data').show();
            $("input#ctitle").prop('required',true);
        }else{
            $('#content_data').hide();  
            $("input#ctitle").prop('required',false); 
        }
    });
    
    $(function(){
        var Text = $('#content').val();
        if (Text == 1) {
            $('#content_data').show();
            $("input#ctitle").prop('required',true);
        }else{
            $('#content_data').hide();  
            $("input#ctitle").prop('required',false); 
        }
    })
</script>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.content-pages.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($contentPage->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter],
        heading: {
            options: [
                { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' },
                { model: 'heading5', view: 'h5', title: 'Heading 5', class: 'ck-heading_heading5' },
                { model: 'heading6', view: 'h6', title: 'Heading 6', class: 'ck-heading_heading6' }
            ]
        }
      }
    );
  }
});
</script>

<script>
    Dropzone.options.featuredImageDropzone = {
    url: '<?php echo e(route('admin.content-pages.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="featured_image"]').remove()
      $('form').append('<input type="hidden" name="featured_image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="featured_image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
    <?php if(isset($contentPage) && $contentPage->featured_image): ?>
        var file = <?php echo json_encode($contentPage->featured_image); ?>

            this.options.addedfile.call(this, file)
        this.options.thumbnail.call(this, file, file.preview)
        file.previewElement.classList.add('dz-complete')
        $('form').append('<input type="hidden" name="featured_image" value="' + file.file_name + '">')
        this.options.maxFiles = this.options.maxFiles - 1
    <?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bestessaywriting/public_html/demo/resources/views/dashboard/admin/menu/sub/create.blade.php ENDPATH**/ ?>