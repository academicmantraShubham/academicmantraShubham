

<?php $__env->startSection('headerData'); ?>
 <!-- seo tags -->
 <title><?php echo e($post->title ?? ''); ?> – Thesis N Dissertation</title>
 <meta name="description" content="<?php echo e($post && $post->excerpt ? substr($post->excerpt, 280) : ''); ?>">
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- Header -->
  <header class="ex-header">
      <div class="container">
          <div class="row">
              <div class="col-xl-10 offset-xl-1">
                  <h2 style="color:white">Services</h2>
              </div> <!-- end of col -->
          </div> <!-- end of row -->
      </div> <!-- end of container -->
  </header> <!-- end of ex-header -->
  <!-- end of header -->

  <!-- About -->
  <?php if(isset($post) && !empty($post)): ?>
  <section class="about d-flex align-items-center text-light py-5" id="about">
      <div class="container" >
          <div class="row d-flex align-items-center">
              <div class="col-lg-7" data-aos="fade-right">
                  <?php echo $post->page_text; ?>


                  <div class="my-3">
                      <a class="btn" href="price.html">Offers</a>
                  </div>
              </div>
              <div class="col-lg-5 text-center py-4 py-sm-0" data-aos="fade-down"> 
                  <img class="img-fluid" src="<?php echo e($post->featured_image ? $post->featured_image->getUrl() : ''); ?>" alt="bestessaywritingservices" >
              </div>
          </div> <!-- end of row -->
      </div> <!-- end of container -->
  </section> <!-- end of about -->
  <?php endif; ?>
  <!-- Services -->
  <section class="services d-flex align-items-center py-5" id="services">
      <div class="container text-light">
        <div class="text-center pb-4" >
              <h2 class="py-2"><?php echo @$team[0]->title; ?></h2>
              <p class="para-light"><?php echo @$team[0]->content; ?></p>
          </div>
          <div class="row gy-4 py-2" data-aos="zoom-in">
          <?php if($post->writers_count > 0): ?>
          <?php $__currentLoopData = $post->writers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-4">
                  <a href=""> <div class="card bg-transparent">                    
                      <h4 class="py-2"><?php echo $item->title; ?></h4>
                      <p class="para-light"><?php echo $item->content; ?></p>
                  </div></a>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

          <?php else: ?>
          <?php $__currentLoopData = $team[0]->subHomepages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4">
            <a href="assignment-help.html"> <div class="card bg-transparent">                    
              <h4 class="py-2"><?php echo $item->title; ?></h4>
              <p class="para-light"><?php echo $item->content; ?></p>
            </div></a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>     

          </div> <!-- end of row -->
      </div> <!-- end of container -->
  </section> <!-- end of services -->
  
  <!-- ======= Frequently Asked Questions Section ======= -->
  <!-- <section  role="img" aria-label="<?php echo e(@$askedquestions[0]->bg_alt); ?>" id="faq" class="faq section-bg" style="<?php echo e(@$askedquestions[0]->bg_color ? 'background:'.@$askedquestions[0]->bg_color.';':''); ?><?php echo e(@$askedquestions[0]->bg_image ?  'background-image: url("'.$askedquestions[0]->bg_image.'");' : ''); ?>">
    <div class="container">

      <div class="section-title">
        <?php echo @$askedquestions[0]->title; ?>

        <?php echo @$askedquestions[0]->content; ?>

      </div>

      <div class="faq-list">
        <ul>
          <?php if($post->faqs_count > 0): ?>
            <?php $__currentLoopData = $post->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php
                    $num = ++$key;
                ?>
                <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" <?php if($num == 1): ?> class="collapse" <?php else: ?> class="collapsed" <?php endif; ?> data-bs-target="#faq-list-<?php echo e($num); ?>"> <?php echo e(strip_tags($item->title)); ?> <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                <div id="faq-list-<?php echo e($num); ?>" class="collapse  <?php if($num == 1): ?> show <?php endif; ?>" data-bs-parent=".faq-list">
                  <?php echo $item->content; ?>

                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
            <?php $__currentLoopData = $askedquestions[0]->subHomepages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php
                    $num = ++$key;
                ?>
                <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" <?php if($num == 1): ?> class="collapse" <?php else: ?> class="collapsed" <?php endif; ?> data-bs-target="#faq-list-<?php echo e($num); ?>"> <?php echo e(strip_tags($item->title)); ?> <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                <div id="faq-list-<?php echo e($num); ?>" class="collapse  <?php if($num == 1): ?> show <?php endif; ?>" data-bs-parent=".faq-list">
                  <?php echo $item->content; ?>

                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </ul>
      </div>

    </div>
  </section>End Frequently Asked Questions Section -->

  <!-- ======= Pricing Section ======= -->
  <!-- <section  role="img" aria-label="<?php echo e(@$bestoffers[0]->bg_alt); ?>" id="pricing" class="pricing" style="<?php echo e(@$bestoffers[0]->bg_color ? 'background:'.@$bestoffers[0]->bg_color.';':''); ?><?php echo e(@$bestoffers[0]->bg_image ?  'background-image: url("'.$bestoffers[0]->bg_image.'");' : ''); ?>">
    <div class="container">

      <div class="section-title">
        <?php echo @$bestoffers[0]->title; ?>

        <?php echo @$bestoffers[0]->content; ?>

      </div>
      <div class="row offers">
          <?php $__currentLoopData = $bestoffers[0]->subHomepages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
              <div class="box <?php if(++$key % 2 == 0): ?>featured <?php endif; ?>">
                  <?php echo @$item->title; ?>

                <?php echo @$item->content; ?>

                <a href="contact" class="buy-btn">Get Started</a>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
  </section>End Pricing Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bestessaywriting/public_html/demo/resources/views/website/pages/post.blade.php ENDPATH**/ ?>