
<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success"  data-toggle="modal" data-target="#add_page" style="color: white">
                <?php echo e(trans('global.add')); ?> HomePage Content of <?php echo e(strip_tags($Homepage->title)); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(strip_tags($Homepage->title)); ?> Content <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <a class="btn btn-default" href="<?php echo e(route('admin.homepage.index')); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Permission">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.menu.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.menu.fields.title')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('Content')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('Image')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $homepages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $homepage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($homepage->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e(++$key ?? ''); ?>

                            </td>
                            <td>
                              <?php echo e(strip_tags($homepage->title) ?? ''); ?> 
                            </td>
                            <td>
                                <?php echo substr(strip_tags($homepage->content),0,25); ?>...
                            </td>
                            <td>
                                <?php if( $homepage->image): ?>
                                    <a href="<?php echo e($homepage->image); ?>" target="_blank" style="display: inline-block">
                                        <img style="width: 55px; height:55px; border-radius:50%;" src="<?php echo e($homepage->image); ?>">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu_edit')): ?>
                                    <a class="btn btn-xs btn-info" style="color: white"  data-toggle="modal" data-target="#add_page<?php echo e($homepage->id); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu_delete')): ?>
                                <form action="<?php echo e(route('admin.homepage.destroy', $homepage->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                </form>
                                <?php endif; ?>

                            </td>
                        </tr>
                            <!-- Update -->
                        <div class="modal fade" id="add_page<?php echo e($homepage->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document" style="max-width:60%">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">&emsp;Edit Content</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>     
                                    <div class="modal-body">
                                    <form  method="POST" action="<?php echo e(route('admin.homepage.update', $homepage->id)); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?> 
                                        <input type="hidden" name="last_url" value="<?php echo e(URL::current()); ?>">
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="parent_id" value="<?php echo e(old('parent_id',  $homepage->parent_id)); ?>">
                                        <div class="row">
                                            <div class="form-group col-12">
                                                <label for="title">Title</label>
                                                <textarea class="form-control ckeditor" type="text" id="title" name="title" placeholder="Enter something...." rows="2"><?php echo e(old('title',  $homepage->title)); ?></textarea>                
                                            </div>
                                            <div class="form-group col-12">
                                                <label for="blog">Content</label>
                                                <textarea class="form-control ckeditor" type="text" id="content" name="content" placeholder="Enter something...." rows="10"><?php echo e(old('content', $homepage->content)); ?></textarea>                
                                            </div>
                                        </div> 
                            
                                            
                                        <div class="row">
                                            <div class="form-group col-12 mt-2">
                                                <label for="title">Image</label>
                                                <input  class="form-control" type="file" name="img">
                                            </div>

                                            <div class="form-group col-12 mt-2">
                                                <label for="title">Alt</label>
                                                <input  class="form-control" type="text" name="alt" value="<?php echo e(old('alt', $homepage->alt)); ?>">
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-success btn-rounded btn-fw">Submit</button>     
                                    </form> 
                                </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
          
                
                <!-- Modal -->
                <div class="modal fade" id="add_page" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document" style="max-width:60%">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">&emsp;Add Content</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>     
                            <div class="modal-body">
                               <form  method="POST" action="<?php echo e(route('admin.homepage.store')); ?>" enctype="multipart/form-data">
                                   <?php echo csrf_field(); ?> 
                                   <input type="hidden" name="last_url" value="<?php echo e(URL::current()); ?>">
                                <input type="hidden" name="parent_id" value="<?php echo e(old('parent_id',  $Homepage->id)); ?>">
                                 <div class="row">
                                    <div class="form-group col-12">
                                        <label for="title">Title</label>
                                        <textarea class="form-control ckeditor" type="text" id="title" name="title" placeholder="Enter something...." rows="2"><?php echo e(old('title')); ?></textarea>                
                                    </div>
                                    <div class="form-group col-12">
                                        <label for="blog">Content</label>
                                        <textarea class="form-control ckeditor" type="text" id="content" name="content" placeholder="Enter something...." rows="10"><?php echo e(old('content')); ?></textarea>                
                                    </div>
                                 </div> 
                    
                                    
                                <div class="row">
                                    <div class="form-group col-12 mt-2">
                                        <label for="title">Image</label>
                                        <input  class="form-control" type="file" name="img">
                                    </div>

                                    <div class="form-group col-12 mt-2">
                                        <label for="title">Alt</label>
                                        <input  class="form-control" type="text" name="alt" value="<?php echo e(old('alt')); ?>">
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success btn-rounded btn-fw">Submit</button>     
                             </form> 
                         </div>
                        </div>
                    </div>
                </div>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[ 1, 'desc' ]],
            pageLength: 100,
        });
        let table = $('.datatable-Permission:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    })
</script>

<script>
    $(document).ready(function() {
        $('.modal').on('shown.bs.modal', function() {
            $('#title').trigger('focus');
        });

        var allEditors = document.querySelectorAll('.ckeditor');
        for (var i = 0; i < allEditors.length; ++i) {
            ClassicEditor.create(
            allEditors[i], {
                toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote' ],
                heading: {
                    options: [
                        { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                        { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                        { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' },
                        { model: 'heading3', view: 'h3', title: 'Heading 3', class: 'ck-heading_heading3' },
                        { model: 'heading4', view: 'h4', title: 'Heading 4', class: 'ck-heading_heading4' },
                        { model: 'heading5', view: 'h5', title: 'Heading 5', class: 'ck-heading_heading5' },
                        { model: 'heading6', view: 'h6', title: 'Heading 6', class: 'ck-heading_heading6' }
                    ]
                }
            }
            );
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bestessaywriting/public_html/demo/resources/views/dashboard/admin/homepage/subindex.blade.php ENDPATH**/ ?>