<!-- Scripts -->
<script src="<?php echo e(asset('website/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/js/purecounter.min.js')); ?>"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>  -->
<?php if('http://127.0.0.1:8000' ==  url()->current() ||  url()->current() == 'https://demo.bestessaywritingservices.com.au' || url()->current() ==  'https://bestessaywritingservices.com.au'): ?>
    <script src="<?php echo e(asset('website/js/swiper.min.js')); ?>"></script>
<?php endif; ?>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="<?php echo e(asset('website/js/script.js?v=1.2')); ?>"></script>


<?php /**PATH /home/bestessaywriting/public_html/demo/resources/views/website/layouts/script.blade.php ENDPATH**/ ?>